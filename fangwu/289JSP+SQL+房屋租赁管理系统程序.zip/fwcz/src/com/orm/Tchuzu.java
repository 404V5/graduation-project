package com.orm;

public class Tchuzu
{
	private int id;
	private String huxing;
	private int mianji;
	private int jiage;
	
	private String beizhu;
	private String dizhi;
	private String lianxiren;
	private String lianxihua;
	
	private String fabushijian;
	private String fujian;
	private int user_id;

	public String getBeizhu()
	{
		return beizhu;
	}

	public void setBeizhu(String beizhu)
	{
		this.beizhu = beizhu;
	}

	public String getDizhi()
	{
		return dizhi;
	}

	public String getFujian()
	{
		return fujian;
	}

	public int getUser_id()
	{
		return user_id;
	}

	public void setUser_id(int user_id)
	{
		this.user_id = user_id;
	}

	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}

	public void setDizhi(String dizhi)
	{
		this.dizhi = dizhi;
	}

	public String getFabushijian()
	{
		return fabushijian;
	}

	public void setFabushijian(String fabushijian)
	{
		this.fabushijian = fabushijian;
	}

	public String getHuxing()
	{
		return huxing;
	}

	public void setHuxing(String huxing)
	{
		this.huxing = huxing;
	}

	public int getId()
	{
		return id;
	}

	public void setId(int id)
	{
		this.id = id;
	}

	public int getJiage()
	{
		return jiage;
	}

	public void setJiage(int jiage)
	{
		this.jiage = jiage;
	}

	public String getLianxihua()
	{
		return lianxihua;
	}

	public void setLianxihua(String lianxihua)
	{
		this.lianxihua = lianxihua;
	}

	public String getLianxiren()
	{
		return lianxiren;
	}

	public void setLianxiren(String lianxiren)
	{
		this.lianxiren = lianxiren;
	}

	public int getMianji()
	{
		return mianji;
	}

	public void setMianji(int mianji)
	{
		this.mianji = mianji;
	}
	
}
