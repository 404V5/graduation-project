package com.model;

public class Fuzhu
{
	private String pingjunfen;
	private TShiti shiti;
	public String getPingjunfen()
	{
		return pingjunfen;
	}
	public void setPingjunfen(String pingjunfen)
	{
		this.pingjunfen = pingjunfen;
	}
	public TShiti getShiti()
	{
		return shiti;
	}
	public void setShiti(TShiti shiti)
	{
		this.shiti = shiti;
	}
	

}
